[![Build Status](https://dev.azure.com/hpcodeway/RunWay/_apis/build/status/runway.terraform-aws-waf?branchName=master)](https://dev.azure.com/hpcodeway/RunWay/_build/latest?definitionId=171&branchName=master)

# AWS WAF Terraform Module

Modules in Terraform are self-contained packages of Terraform configurations that are managed as a group. Modules are used to create reusable components in Terraform as well as for basic code organization. Please review the Terraform documentation to become familiar with Modules: https://www.terraform.io/docs/modules/usage.html

This repo contains the following folder structure:

* [modules](./modules) contain several standalone, reusable, production-grade modules.
* [examples](./examples) contain examples that combine the modules in the `modules` folder to deploy real infrastructure.
* [test](./test) contain integration tests for the modules and examples.

## Requirements

1. Install [Terraform](https://www.terraform.io/downloads.html).
1. For scripting requirements, please use [Python3](https://www.python.org/downloads/).
1. For integration tests, please refer to the test requirements documented at [test/README.md](/test/README.md).

### Supported Operating Systems:

- [Linux](https://www.linux.org/)
- [Windows](https://www.microsoft.com/en-us/windows)

## Modules

For additional parameters you can use to customize each module, please read the `README.md` inside the module and check out the `examples/` folder for working sample code.

* [waf-logger](./modules/waf-logger/README.md)
* [waf-regional-rules](./modules/waf-regional-rules/README.md)
* [waf-regional-web-acl](./modules/waf-regional-web-acl/README.md)
* [waf-rules](./modules/waf-rules/README.md)
* [waf-web-acl](./modules/waf-web-acl/README.md)

## Note about WCUs

AWS WAF uses web ACL capacity units (WCU) to calculate and control the operating resources that are required to run your rules, rule groups, and web ACLs. AWS WAF enforces WCU limits when you configure your rule groups and web ACLs [1]. The current limits are:

 * Maximum number of web ACL capacity units in a web ACL in WAF for regional: 1500
 * Maximum number of web ACL capacity units in a rule group in WAF for regional: 1500

if you choose to enable additional rule sets, there is a change you will go over this quota. See table below:

| Name                                     |  WCU  | Type              |
|------------------------------------------|-------|-------------------|
| AWSManagedRulesCommonRuleSet             |  700  | Baseline          |
| AWSManagedRulesAdminProtectionRuleSet    |  100  | Baseline          |
| AWSManagedRulesKnownBadInputsRuleSet     |  200  | baseline          |
| AWSManagedRulesAmazonIpReputationList    |   25  | IP Reputation     |
| AWSManagedRulesAnonymousIpList           |   50  | IP Reputation     |
| AWSManagedRulesBotControlRuleSet         |   50  | Bot Control       |
| AWSManagedRulesATPRuleSet                |   50  | Account Takeover  |
| AWSManagedRulesSQLiRuleSet               |  200  | Use case specific |
| AWSManagedRulesLinuxRuleSet              |  200  | Use case specific |
| AWSManagedRulesUnixRuleSet               |  100  | Use case specific |
| AWSManagedRulesWindowsRuleSet            |  200  | Use case specific |
| AWSManagedRulesPHPRuleSet                |  100  | Use case specific |
| AWSManagedRulesWordPressRuleSet          |  100  | Use case specific |

## Considerations when enabling Managed Rules

 - Set a specific rule group version using the 'managed_rule_group_version'. By default, whenever the version is not set, it automatically updates the version whenever AWS releases a new rule group.
 - The AdminProtection_URIPATH rule under AWSManagedRulesAdminProtectionRuleSet will block any url that resembles an adminstration page.
 - The HostingProviderIPList under AWSManagedRulesAnonymousIpList will block all traffic if you are using it on a load balancer receiving traffic from Apigee

## Issues

### Bugs

If you have found a bug please follow the instructions below:

- Spend a small amount of time giving due diligence to the issue tracker. Your issue might be a duplicate.
- Open a [new issue](../../issues/new).
- Inform what module version you are using.
- Paste in the issue the `terraform.tfvars` that you are using.
- Paste in the issue the `terraform plan` and `terraform apply` output.
- Remember, users might be searching for your issue in the future, so please give it a meaningful title to helps others.

### Features

If you have an idea for a new feature follow the steps below.

- Open a [new issue](../../issues/new).
- Remember, users might be searching for your issue in the future, so please give it a meaningful title to helps others.
- Clearly define the use case, using concrete examples.
- If you would like to include a technical design for your feature please include it in the issue.
- Feel free to code it yourself. Open up a pull request and happy coding.

## Contributing

Pull requests are welcome on GitHub. This project is intended to be a safe, welcoming space for collaboration, and contributors are expected to adhere to the [Contributors' Guide](https://pages.github.azc.ext.hp.com/runway/community/contribute/).
