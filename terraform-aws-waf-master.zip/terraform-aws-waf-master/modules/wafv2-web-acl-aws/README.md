# AWS WAF MANAGED
This module configures AWS WAF with AWS Managed Rules.

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_wafv2_ip_set.ip_rule_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_ip_set) | resource |
| [aws_wafv2_regex_pattern_set.regex_pattern_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_regex_pattern_set) | resource |
| [aws_wafv2_web_acl.waf_acl](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl) | resource |
| [aws_wafv2_web_acl_association.waf_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl_association) | resource |
| [aws_wafv2_web_acl_logging_configuration.waf_logging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafv2_web_acl_logging_configuration) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_additional_rule_sets"></a> [additional\_rule\_sets](#input\_additional\_rule\_sets) | List of additional rule sets to be added to the WAF. Only AWS managed rule sets are currently supported | `list(string)` | `[]` | no |
| <a name="input_cloudwatch_metrics_enabled"></a> [cloudwatch\_metrics\_enabled](#input\_cloudwatch\_metrics\_enabled) | n/a | `bool` | `true` | no |
| <a name="input_default_action"></a> [default\_action](#input\_default\_action) | Default Action for the Web ACL. ALLOW/BLOCK are two supported actions | `string` | `"allow"` | no |
| <a name="input_description"></a> [description](#input\_description) | WAF description | `string` | `"Managed by Terraform"` | no |
| <a name="input_firehose_arn"></a> [firehose\_arn](#input\_firehose\_arn) | ARN of the Firehose Stream | `string` | `null` | no |
| <a name="input_ip_rate_uri_based_regex_rule_set"></a> [ip\_rate\_uri\_based\_regex\_rule\_set](#input\_ip\_rate\_uri\_based\_regex\_rule\_set) | A rate and url based rules tracks the rate of requests for each originating IP address, and triggers the rule action when the rate exceeds a limit that you specify on the number of requests in any 5-minute time span | <pre>object({<br>    name        = string<br>    description = string<br>    regex       = list(string)<br>    priority    = number<br>    limit       = number<br>    action      = string<br><br>  })</pre> | `null` | no |
| <a name="input_ip_rule_whitelist"></a> [ip\_rule\_whitelist](#input\_ip\_rule\_whitelist) | List of IP Address for WAF custom IP rule | `list(string)` | `[]` | no |
| <a name="input_managed_rule_group_version"></a> [managed\_rule\_group\_version](#input\_managed\_rule\_group\_version) | Sets a rule group version. Input is an object with keys as rule group name and value as rule group version. If a rule group has no value set it uses 'Default' | `map(string)` | `{}` | no |
| <a name="input_name"></a> [name](#input\_name) | WAF name | `string` | `""` | no |
| <a name="input_override_managed_rules"></a> [override\_managed\_rules](#input\_override\_managed\_rules) | WAF Rules and Exceptions to override | `map(list(string))` | `{}` | no |
| <a name="input_redacted_fields"></a> [redacted\_fields](#input\_redacted\_fields) | Redact Fields are required. Members of list describes the redacted fields | `map(list(string))` | <pre>{<br>  "single_header": [],<br>  "single_query_argument": []<br>}</pre> | no |
| <a name="input_resource_arn"></a> [resource\_arn](#input\_resource\_arn) | ARN of the Resource to be associated with WAF. If you need to associate it with a Cloudfront distribution you should use the web\_acl\_id property on the cloudfront\_distribution instead. | `string` | `null` | no |
| <a name="input_rule_action"></a> [rule\_action](#input\_rule\_action) | n/a | `string` | `"count"` | no |
| <a name="input_sampled_requests_enabled"></a> [sampled\_requests\_enabled](#input\_sampled\_requests\_enabled) | Sample Request Enabled/Disabled(True/False) | `bool` | `true` | no |
| <a name="input_scope"></a> [scope](#input\_scope) | n/a | `string` | `"REGIONAL"` | no |
| <a name="input_size_constraint"></a> [size\_constraint](#input\_size\_constraint) | Creates a rule group with a size constraint | `number` | `0` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add into all resources. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_web_acl_arn"></a> [web\_acl\_arn](#output\_web\_acl\_arn) | n/a |
| <a name="output_web_acl_id"></a> [web\_acl\_id](#output\_web\_acl\_id) | n/a |
<!-- END_TF_DOCS -->