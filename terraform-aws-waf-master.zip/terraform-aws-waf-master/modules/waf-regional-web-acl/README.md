# AWS WAF-Regional WebACL

This module creates a WebACL that links to an existing rule group for WAF, potentially helping to mitigate OWASP attacks.

## Usage

### Connect to an Application Load Balancer or API Gateway
This module may be used before or after creating these resources.
If you choose, and if you run this module after those resources, you may include ARNs of any load balancers and API Gateway instances to be linked to your WebACL in the `resource_arns` variable.

### Logging
The `waf-logger` module can create a logging instance for this WebACL.
The logger must be in the same region as your WebACL.
The logger module returns a `firehose_stream_arn` which can be input into this module.

### Shared Rules
The VPC setup module creates rules for WAF Regional.
There will be a rule group for blocking, and a single URI regex match rule for exceptions.

## Variables

### Input Variables

| Field                         | Required | Description                                                                                       | Default Value
| ----------------------------- | -------- | ------------------------------------------------------------------------------------------------- | -------------
| `aws_region`                  | Yes      | Region for the Web ACL resources.                                                                 |
| `app_name`                    | Yes      | Application name.                                                                                 |
| `environment`                 | Yes      | Application environment.                                                                          |
| `waf_rule_group_id`           | Yes      | ID of rule group that will typically block potentially malicious requests.                        |
| `waf_allow_rule_id`           | No       | ID of rule that will act as an exception to the blocking rule group.                              | `""`
| `web_acl_metric_name`         | Yes      | Metric name for the WebACL in CloudWatch (must be alphanumeric).                                  |
| `web_acl_default_action`      | No       | Default action for requests that are not processed by a rule (`"ALLOW"` or `BL"OCK`).             | `"ALLOW"`
| `web_acl_override_action`     | No       | Override action for requests that are blocked by the included rule group (`"COUNT"` or `"NONE"`). | `"NONE"`
| `resource_arns`               | No       | Provide ARNs of ALBs or API Gateway instances to link to.                                         | `[]`
| `firehose_stream_arn`         | No       | Provide ARN of Kinesis Firehose Delivery Stream for log output.                                   | `""`

### Output Variables

| Field        | Description
| ------------ | ----------------
| `web_acl_id` | ID of the WebACL

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_wafregional_web_acl.wafregional_web_acl](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafregional_web_acl) | resource |
| [aws_wafregional_web_acl_association.wafregional_web_acl_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/wafregional_web_acl_association) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | Name of your application (used for WebACL name) | `string` | n/a | yes |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | Region for WAF resources.  Use "global" for CloudFront or a region id for an ALB or API Gateway. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | AWS environment (used for WebACL name) | `string` | n/a | yes |
| <a name="input_firehose_stream_arn"></a> [firehose\_stream\_arn](#input\_firehose\_stream\_arn) | ARN of Kinesis Firehose for logging (must be in same region as this WebACL) | `string` | `""` | no |
| <a name="input_resource_arns"></a> [resource\_arns](#input\_resource\_arns) | ARN of ALB or API Gateway resource to link to.  Optional, and only valid if aws\_region is not "global". | `list(string)` | `[]` | no |
| <a name="input_waf_allow_rule_id"></a> [waf\_allow\_rule\_id](#input\_waf\_allow\_rule\_id) | Rule ID for the "ALLOW" rule exception, placed ahead of the rule group for evaluation. | `string` | `""` | no |
| <a name="input_waf_rule_group_id"></a> [waf\_rule\_group\_id](#input\_waf\_rule\_group\_id) | Rule ID for tne "BLOCK" rule group. | `string` | n/a | yes |
| <a name="input_web_acl_default_action"></a> [web\_acl\_default\_action](#input\_web\_acl\_default\_action) | Action for traffic which has had no action taken by the WebACL.  "ALLOW" is standard. | `string` | `"ALLOW"` | no |
| <a name="input_web_acl_metric_name"></a> [web\_acl\_metric\_name](#input\_web\_acl\_metric\_name) | Metric name for the WebACL.  Must be alphanumeric. | `string` | n/a | yes |
| <a name="input_web_acl_override_action"></a> [web\_acl\_override\_action](#input\_web\_acl\_override\_action) | Override action for WebACL.  May be "NONE" (blocks incoming malicious requests) or "COUNT" (does not block). | `string` | `"NONE"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_web_acl_id"></a> [web\_acl\_id](#output\_web\_acl\_id) | n/a |
<!-- END_TF_DOCS -->