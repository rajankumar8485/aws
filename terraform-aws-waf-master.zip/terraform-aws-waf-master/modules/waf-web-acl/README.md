# AWS WAF WebACL

This module creates a WebACL that links to an existing rule group for WAF, potentially helping to mitigate OWASP attacks.

## Usage

### Connect to CloudFront
This module must be used before creating/updating a CloudFront distribution.
Include the value exported in the `web_acl_id` variable when creating your `aws_cloudfront_distribution` resource in its `web_acl_id` variable.

### Logging
The `waf-logger` module can create a logging instance for this WebACL.
Your logger must be in `us-east-1`.
The logger module returns a `firehose_stream_arn` which can be input into this module.

### Shared Rules
The AWS account setup creates some shared rules for WAF, and the VPC setup does the same for WAF Regional.
Each creates a rule group for blocking, and a single URI regex match rule for exceptions.


<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_waf_web_acl.waf_web_acl](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_web_acl) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | Name of your application (used for WebACL name) | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | AWS environment (used for WebACL name) | `string` | n/a | yes |
| <a name="input_firehose_stream_arn"></a> [firehose\_stream\_arn](#input\_firehose\_stream\_arn) | ARN of Kinesis Firehose for logging (must be in same region as this WebACL) | `string` | `""` | no |
| <a name="input_resource_arns"></a> [resource\_arns](#input\_resource\_arns) | ARN of ALB or API Gateway resource to link to.  Optional, and only valid if aws\_region is not "global". | `list(string)` | `[]` | no |
| <a name="input_waf_allow_rule_id"></a> [waf\_allow\_rule\_id](#input\_waf\_allow\_rule\_id) | Rule ID for the "ALLOW" rule exception, placed ahead of the rule group for evaluation. | `string` | `""` | no |
| <a name="input_waf_rule_group_id"></a> [waf\_rule\_group\_id](#input\_waf\_rule\_group\_id) | Rule ID for tne "BLOCK" rule group. | `string` | n/a | yes |
| <a name="input_web_acl_default_action"></a> [web\_acl\_default\_action](#input\_web\_acl\_default\_action) | Action for traffic which has had no action taken by the WebACL.  "ALLOW" is standard. | `string` | `"ALLOW"` | no |
| <a name="input_web_acl_metric_name"></a> [web\_acl\_metric\_name](#input\_web\_acl\_metric\_name) | Metric name for the WebACL.  Must be alphanumeric. | `string` | n/a | yes |
| <a name="input_web_acl_override_action"></a> [web\_acl\_override\_action](#input\_web\_acl\_override\_action) | Override action for WebACL.  May be "NONE" (blocks incoming malicious requests) or "COUNT" (does not block). | `string` | `"NONE"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_web_acl_id"></a> [web\_acl\_id](#output\_web\_acl\_id) | n/a |
<!-- END_TF_DOCS -->