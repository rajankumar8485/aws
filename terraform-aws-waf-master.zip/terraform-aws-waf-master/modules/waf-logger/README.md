# AWS WAF Logger

This module creates a set of resources designed to log AWS WAF data.
It creates a Kinesis Firehose, a Lambda, appropriate IAM roles, and an S3 bucket to store log data.
The Lambda is designed to process WAF data and drop irrelevant records before storage in S3.

## Usage

### WAF - CloudFront
Give this module an AWS provider with region `us-east-1`.

### WAF Regional - Application Load Balancer or API Gateway
Give this module an AWS provider with the same region as your WebACL.

### S3 Logging (standard behavior)
The Kinesis Firehose will deliver processed logs to an S3 bucket.

### ElasticSearch Logging (requires extra app-specific work)
If you use Serverless, you can use the `serverless-es-logs` plugin to pipe all your app logs to ElasticSearch.
Add a function which runs on an interval and reads all WAF log data from S3, and prints it to its own console in JSON format.
The plugin should read this data and forward it to ElasticSearch with all your other logs.

## Variables

### Input Variables

| Field                         | Required | Description                                                                     | Default Value
| ----------------------------- | -------- | ------------------------------------------------------------------------------- | -------------
| `aws_region`                  | Yes      | Region for the Web ACL resources.  Should be "us-east-1" for CloudFront.        |
| `app_name`                    | Yes      | Application name.                                                               |
| `environment`                 | Yes      | Application environment.                                                        |
| `tags`                        | No       | Resource tags map.                                                              | `{}`

### Output Variables

| Field                 | Description
| --------------------- | ------------------------------------------------
| `firehose_stream_arn` | Kinesis Firehose Stream ARN for `web-acl` module
| `lambda_role_arn`     | RoleARN for the Lambda
| `lambda_role_id`      | RoleID for the Lambda
| `lambda_arn`          | ARN for the Lambda
| `lambda_name`         | Name of the Lambda
| `firehose_role_arn`   | RoleARN for the Kinesis Firehose
| `firehose_role_id`    | RoleID for the Kinesis Firehose


<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_log_group.waf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_iam_role.waf_firehose](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.waf_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.waf_firehose](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.waf_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_kinesis_firehose_delivery_stream.firehose](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kinesis_firehose_delivery_stream) | resource |
| [aws_lambda_function.waf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_s3_bucket.logs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.waf_firehose_assume_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.waf_firehose_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.waf_lambda_assume_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.waf_lambda_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_name"></a> [app\_name](#input\_app\_name) | Application name | `any` | n/a | yes |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | Common Variables | `any` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | Application environment | `any` | n/a | yes |
| <a name="input_name_suffix"></a> [name\_suffix](#input\_name\_suffix) | The name suffix to be used on the resources created by this module. If null it will use the format 'aws\_region-environment-app\_name' | `string` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Map containing tags to associate to AWS resources. | `map(any)` | `{}` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_firehose_role_arn"></a> [firehose\_role\_arn](#output\_firehose\_role\_arn) | n/a |
| <a name="output_firehose_role_id"></a> [firehose\_role\_id](#output\_firehose\_role\_id) | n/a |
| <a name="output_firehose_stream_arn"></a> [firehose\_stream\_arn](#output\_firehose\_stream\_arn) | n/a |
| <a name="output_lambda_arn"></a> [lambda\_arn](#output\_lambda\_arn) | n/a |
| <a name="output_lambda_name"></a> [lambda\_name](#output\_lambda\_name) | n/a |
| <a name="output_lambda_role_arn"></a> [lambda\_role\_arn](#output\_lambda\_role\_arn) | n/a |
| <a name="output_lambda_role_id"></a> [lambda\_role\_id](#output\_lambda\_role\_id) | n/a |
| <a name="output_logs_s3_bucket_arn"></a> [logs\_s3\_bucket\_arn](#output\_logs\_s3\_bucket\_arn) | n/a |
| <a name="output_logs_s3_bucket_id"></a> [logs\_s3\_bucket\_id](#output\_logs\_s3\_bucket\_id) | n/a |
<!-- END_TF_DOCS -->