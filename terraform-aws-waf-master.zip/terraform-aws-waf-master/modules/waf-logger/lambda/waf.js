"use strict";

const BLOCKED_RECORD = Buffer.from('"action":"BLOCK"', "utf8");

async function processRecords({ records: rawRecords = [] } = {}) {
  const records = [];

  for (const { data, recordId } of rawRecords) {
    const buffer = Buffer.from(data, "base64");

    const result = buffer.includes(BLOCKED_RECORD) ? "Ok" : "Dropped";
    records.push({ recordId, result, data });
  }

  return { records: records };
}

exports.processRecords = processRecords;
