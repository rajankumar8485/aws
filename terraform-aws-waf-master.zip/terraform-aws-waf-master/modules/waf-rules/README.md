<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_waf_byte_match_set.match_php_insecure_qs_string_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_byte_match_set) | resource |
| [aws_waf_byte_match_set.match_php_insecure_uri_string_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_byte_match_set) | resource |
| [aws_waf_byte_match_set.match_rfi_lfi_traversal_string_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_byte_match_set) | resource |
| [aws_waf_byte_match_set.match_server_side_include_string_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_byte_match_set) | resource |
| [aws_waf_byte_match_set.method_csrf_string_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_byte_match_set) | resource |
| [aws_waf_regex_match_set.allow_uri_regex_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_regex_match_set) | resource |
| [aws_waf_regex_pattern_set.allow_uri_regex_pattern_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_regex_pattern_set) | resource |
| [aws_waf_rule.rule_allow_uri](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_csrf](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_insecure_php](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_rfi_lfi_traversal](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_server_side_include](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_size](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_sqli](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule.rule_xss](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule) | resource |
| [aws_waf_rule_group.waf_rule_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_rule_group) | resource |
| [aws_waf_size_constraint_set.csrf_token_size_constrain_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_size_constraint_set) | resource |
| [aws_waf_size_constraint_set.size_constraint_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_size_constraint_set) | resource |
| [aws_waf_sql_injection_match_set.sql_injection_match_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_sql_injection_match_set) | resource |
| [aws_waf_xss_match_set.xss_match_set](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/waf_xss_match_set) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | Common Variables | `string` | `"global"` | no |
| <a name="input_csrf_token_comparison_operator"></a> [csrf\_token\_comparison\_operator](#input\_csrf\_token\_comparison\_operator) | Different type of comparisons that can be made;GT, LT, EQ. | `string` | `"GT"` | no |
| <a name="input_csrf_token_header_type"></a> [csrf\_token\_header\_type](#input\_csrf\_token\_header\_type) | The type of token to be looked for in the header;'x-csrf-token', 'authorization',etc.. | `string` | `"authorization"` | no |
| <a name="input_csrf_token_size"></a> [csrf\_token\_size](#input\_csrf\_token\_size) | Length in bytes of the token | `string` | `"1"` | no |
| <a name="input_extra_rules"></a> [extra\_rules](#input\_extra\_rules) | List of extra rule IDs to include (priority will be assigned in order 50-99) | `list(any)` | `[]` | no |
| <a name="input_metric_prefix"></a> [metric\_prefix](#input\_metric\_prefix) | n/a | `string` | `""` | no |
| <a name="input_resource_prefix"></a> [resource\_prefix](#input\_resource\_prefix) | n/a | `string` | `""` | no |
| <a name="input_rfi_lfi_traversal_target_string_0"></a> [rfi\_lfi\_traversal\_target\_string\_0](#input\_rfi\_lfi\_traversal\_target\_string\_0) | The file path string that is looked for in the httpRequest['URI'] field. | `string` | `"file="` | no |
| <a name="input_rfi_lfi_traversal_target_string_1"></a> [rfi\_lfi\_traversal\_target\_string\_1](#input\_rfi\_lfi\_traversal\_target\_string\_1) | The file path string that is looked for in the httpRequest['URI'] field. | `string` | `"http://"` | no |
| <a name="input_rfi_lfi_traversal_target_string_2"></a> [rfi\_lfi\_traversal\_target\_string\_2](#input\_rfi\_lfi\_traversal\_target\_string\_2) | The file path string that is looked for in the httpRequest['URI'] field. | `string` | `"ftp="` | no |
| <a name="input_rule_allow_metric_name"></a> [rule\_allow\_metric\_name](#input\_rule\_allow\_metric\_name) | n/a | `string` | `""` | no |
| <a name="input_rule_allow_uri_regex_list"></a> [rule\_allow\_uri\_regex\_list](#input\_rule\_allow\_uri\_regex\_list) | WAF URL Whitelist | `list(string)` | `[]` | no |
| <a name="input_rule_block_metric_name"></a> [rule\_block\_metric\_name](#input\_rule\_block\_metric\_name) | n/a | `string` | `""` | no |
| <a name="input_rule_group_metric_name"></a> [rule\_group\_metric\_name](#input\_rule\_group\_metric\_name) | WAF CloudWatch metrics | `string` | `""` | no |
| <a name="input_rule_size_constraint_body"></a> [rule\_size\_constraint\_body](#input\_rule\_size\_constraint\_body) | n/a | `number` | `8388608` | no |
| <a name="input_rule_size_constraint_querystring"></a> [rule\_size\_constraint\_querystring](#input\_rule\_size\_constraint\_querystring) | n/a | `number` | `8192` | no |
| <a name="input_rule_size_constraint_uri"></a> [rule\_size\_constraint\_uri](#input\_rule\_size\_constraint\_uri) | WAF Size Constraints | `number` | `8192` | no |
| <a name="input_use_csrf"></a> [use\_csrf](#input\_use\_csrf) | Rule to mandate/validate a header | `bool` | `false` | no |
| <a name="input_use_insecure_php"></a> [use\_insecure\_php](#input\_use\_insecure\_php) | Rule to block some potential PHP vulnerabilities | `bool` | `false` | no |
| <a name="input_use_rfi_lfi_traversal"></a> [use\_rfi\_lfi\_traversal](#input\_use\_rfi\_lfi\_traversal) | RFI/LFI traversal rule | `bool` | `false` | no |
| <a name="input_use_server_side_include"></a> [use\_server\_side\_include](#input\_use\_server\_side\_include) | Rule to block some URI filename extensions | `bool` | `false` | no |
| <a name="input_use_size"></a> [use\_size](#input\_use\_size) | Whether to enforce request size constraints | `bool` | `true` | no |
| <a name="input_use_sqli"></a> [use\_sqli](#input\_use\_sqli) | Rule to perform automatic SQL injection checks | `bool` | `true` | no |
| <a name="input_use_xss"></a> [use\_xss](#input\_use\_xss) | Rule to perform automatic XSS injection checks | `bool` | `true` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_waf_allow_rule_id"></a> [waf\_allow\_rule\_id](#output\_waf\_allow\_rule\_id) | n/a |
| <a name="output_waf_rule_group_id"></a> [waf\_rule\_group\_id](#output\_waf\_rule\_group\_id) | n/a |
<!-- END_TF_DOCS -->