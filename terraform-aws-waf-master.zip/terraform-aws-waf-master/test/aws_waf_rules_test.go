package test

import (
	"testing"

	"github.azc.ext.hp.com/runway/terratest-lib/v3/pkg/commons"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func createWafRulesModule(t *testing.T) {
	t.Parallel()
	commons.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
	})

	opts := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/create-waf-rules"),
	}

	// Delete The resources after they have been provisioned
	defer terraform.Destroy(t, opts)

	// Check and then provision the resources
	terraform.InitAndApply(t, opts)

	webRuleGroupID := terraform.Output(t, opts, "waf_rule_group_id")
	wafAllowRuleID := terraform.Output(t, opts, "waf_allow_rule_id")

	assert.NotEqual(t, "", webRuleGroupID, "WAF rule group id should not be an empty string")
	assert.NotEqual(t, "", wafAllowRuleID, "WAF allow rule id should not be an empty string")
}
