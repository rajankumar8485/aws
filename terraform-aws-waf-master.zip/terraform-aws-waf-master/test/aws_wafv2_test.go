package test

import (
	"testing"

	"github.azc.ext.hp.com/runway/terratest-lib/v3/pkg/commons"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func createWafv2Aws(t *testing.T) {
	t.Parallel()
	commons.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
	})

	wafName := commons.GenerateUniqueName()

	opts := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/wafv2-aws"),

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"name": wafName,
		},

		// Disable colors in Terraform commands so its easier to parse stdout/stderr
		NoColor: true,
	}

	// Delete The resources after they have been provisioned
	defer terraform.Destroy(t, opts)

	// Check and then provision the resources
	terraform.InitAndApply(t, opts)

	webAclId := terraform.Output(t, opts, "web_acl_id")
	assert.NotEqual(t, "", webAclId, "WAF ID should not be an empty string")
}

func createWafv2AwsWithCustomRules(t *testing.T) {
	t.Parallel()
	commons.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
	})

	wafName := commons.GenerateUniqueName()
	ipWhitelist := []string{"15.0.0.0/9"}

	opts := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/wafv2-aws"),

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"name":              wafName,
			"ip_rule_whitelist": ipWhitelist,
			"size_constraint":   1024,
		},

		// Disable colors in Terraform commands so its easier to parse stdout/stderr
		NoColor: true,
	}

	// Delete The resources after they have been provisioned
	defer terraform.Destroy(t, opts)

	// Check and then provision the resources
	terraform.InitAndApply(t, opts)

	webAclId := terraform.Output(t, opts, "web_acl_id")
	assert.NotEqual(t, "", webAclId, "WAF ID should not be an empty string")
}

func createWafv2AwsWithRateBasedRegexRules(t *testing.T) {
	t.Parallel()
	commons.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
	})

	wafName := commons.GenerateUniqueName() + "-rateBasedWaf"
	ipRateUriBasedRegexRuleSet := map[string]interface{}{
		"regex": []string{
			"/services/license_service/1.0/license/[A-Z0-9]{18}/hello.html",
			"/services/license_service/1.0/license/[A-Z0-9]{12}/hello.html",
		},
		"name":        "ip-rate-limit-rule-regex",
		"description": "test-description",
		"priority":    "4",
		"action":      "block",
		"limit":       "100",
	}

	opts := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/wafv2-aws"),

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"name":                             wafName,
			"ip_rate_uri_based_regex_rule_set": ipRateUriBasedRegexRuleSet,
		},

		// Disable colors in Terraform commands so its easier to parse stdout/stderr
		NoColor: true,
	}

	// Delete The resources after they have been provisioned
	defer terraform.Destroy(t, opts)

	// Check and then provision the resources
	terraform.InitAndApply(t, opts)

	webAclId := terraform.Output(t, opts, "web_acl_id")
	assert.NotEqual(t, "", webAclId, "WAF ID should not be an empty string")
}
