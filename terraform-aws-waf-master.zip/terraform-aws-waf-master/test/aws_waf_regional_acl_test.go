package test

import (
	"testing"

	"github.azc.ext.hp.com/runway/terratest-lib/v3/pkg/commons"
	"github.com/gruntwork-io/terratest/modules/terraform"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func createWafRegionalAcl(t *testing.T) {
	t.Parallel()
	commons.CheckRequiredVariables(t, []string{
		"TF_VAR_region",
		"TF_VAR_role_path",
	})

	appName := commons.GenerateUniqueName()

	opts := &terraform.Options{
		TerraformDir: test_structure.CopyTerraformFolderToTemp(t, "../", "examples/waf-with-ecs-module-alb-or-api-gateway"),

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"app_name": appName,
		},

		// Disable colors in Terraform commands so its easier to parse stdout/stderr
		NoColor: true,
	}
	// Delete The resources after they have been provisioned
	defer terraform.Destroy(t, opts)

	// Check and then provision the resources
	terraform.InitAndApply(t, opts)
}
