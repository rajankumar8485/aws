# Changelog

## 4.0
- Removed IP reputation list from default rule sets. To add it again, use the additional_rule_sets variable. See the note about WCUs in README.md for details
